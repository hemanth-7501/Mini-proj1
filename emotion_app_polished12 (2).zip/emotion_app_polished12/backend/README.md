Backend: Flask API for inference. See requirements.txt.
