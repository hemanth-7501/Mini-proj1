import os, io
from PIL import Image
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
import torch
import torchvision.transforms as T
import cv2

# Try to import model class from repo root
try:
    from model import EmotionIntensityModel
    MODEL_CLASS_AVAILABLE = True
except Exception as e:
    MODEL_CLASS_AVAILABLE = False
    MODEL_IMPORT_ERR = str(e)

EMOTION_LABELS = ['Angry','Disgust','Fear','Happy','Sad','Surprise','Neutral']

app = Flask(__name__)
CORS(app)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

transform = T.Compose([
    T.Resize((224,224)),
    T.ToTensor(),
    T.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])
])

DEFAULT_MODEL_PATHS = [
    "emotion_vnn_model.pt",
    "checkpoints/emotion_intensity_model.pth",
    "models/emotion_vnn_model.pt"
]

MODEL = None

def load_model():
    global MODEL
    if not MODEL_CLASS_AVAILABLE:
        raise ImportError(f"model.py not importable from repo root. Error: {MODEL_IMPORT_ERR}")

    model = EmotionIntensityModel(num_classes=len(EMOTION_LABELS))
    model.to(device)
    model.eval()
    ckpt = None
    ckpt_path = None
    for p in DEFAULT_MODEL_PATHS:
        if os.path.exists(p):
            ckpt_path = p
            break
    if ckpt_path is None:
        raise FileNotFoundError(f"No checkpoint found. Put your checkpoint at one of {DEFAULT_MODEL_PATHS}")

    try:
        loaded = torch.load(ckpt_path, map_location=device)
        if isinstance(loaded, dict):
            if 'model_state_dict' in loaded:
                model.load_state_dict(loaded['model_state_dict'])
            else:
                model.load_state_dict(loaded)
        else:
            model = loaded
    except Exception as e:
        raise RuntimeError(f"Failed to load model from {ckpt_path}: {e}")

    model.to(device)
    model.eval()
    MODEL = model
    return MODEL

def preprocess_image_bytes(img_bytes):
    image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    tensor = transform(image).unsqueeze(0).to(device)
    return tensor

def detect_faces_and_predict(img_bytes):
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Received image could not be decoded by OpenCV")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
    results = []
    if len(faces) == 0:
        if MODEL is None:
            # dummy uniform low scores
            scores = [0.05]*len(EMOTION_LABELS); scores[3]=0.6
            results.append({"bbox": None, "scores": scores, "top":{"emotion": EMOTION_LABELS[int(np.argmax(scores))],"score": float(np.max(scores))}})
            return results
        tensor = preprocess_image_bytes(img_bytes)
        with torch.no_grad():
            preds = MODEL(tensor)
            preds = preds.squeeze(0).cpu().numpy().tolist()
        results.append({"bbox": None, "scores": preds, "top":{"emotion": EMOTION_LABELS[int(np.argmax(preds))],"score": float(np.max(preds))}})
        return results

    for (x,y,w,h) in faces:
        face_img = img[y:y+h, x:x+w]
        _, buf = cv2.imencode('.jpg', face_img)
        face_bytes = buf.tobytes()
        if MODEL is None:
            scores = [0.05]*len(EMOTION_LABELS); scores[3]=0.6
        else:
            tensor = preprocess_image_bytes(face_bytes)
            with torch.no_grad():
                preds = MODEL(tensor)
                preds = preds.squeeze(0).cpu().numpy().tolist()
            scores = preds
        top_idx = int(np.argmax(scores))
        results.append({
            "bbox": [int(x),int(y),int(w),int(h)],
            "scores": scores,
            "top": {"emotion": EMOTION_LABELS[top_idx], "score": float(scores[top_idx])}
        })
    return results

@app.route("/api/predict", methods=["POST"])
def predict():
    global MODEL
    if MODEL is None and MODEL_CLASS_AVAILABLE:
        try:
            MODEL = load_model()
        except Exception as e:
            app.logger.warning(f"Model load warning: {e}")

    if 'image' not in request.files:
        return jsonify({"error":"Please send image in form-data under key 'image'"}), 400
    file = request.files['image']
    img_bytes = file.read()
    try:
        results = detect_faces_and_predict(img_bytes)
    except Exception as e:
        return jsonify({"error": f"Inference error: {str(e)}"}), 500

    return jsonify({"results": results})

@app.route("/")
def index():
    return jsonify({"status":"ok","message":"Emotion API up. Use /api/predict (POST) with form-data 'image'."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
