import torch
from models.emotion_intensity_model import EmotionIntensityModel

m = EmotionIntensityModel()
print('Backbone class:', m.backbone.__class__)
try:
    print('backbone.num_features =', m.backbone.num_features)
except Exception as e:
    print('num_features attribute error:', e)

x = torch.randn(1,3,224,224)
try:
    out = m(x)
    print('Output shape =', out.shape)
except Exception as e:
    print('Forward error:', e)
