import timm
import torch.nn as nn

class EmotionIntensityModel(nn.Module):
    def __init__(self, num_emotions=7, model_name='efficientnet_b0', pretrained=True):
        super().__init__()
        # Create the backbone model without its classification head
        self.backbone = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0,  # Remove the classification head
            global_pool='avg'  # Use average pooling
        )
        
        # Get the correct number of features
        num_features = self.backbone.num_features
        
        # Add custom classifier with dropout for regularization
        self.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(num_features, num_emotions)
        )

    def forward(self, x):
        features = self.backbone(x)
        return self.classifier(features)
