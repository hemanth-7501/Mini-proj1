import torch
import torch.nn as nn
import torch.optim as optim
import torch.multiprocessing as mp
from models.emotion_intensity_model import EmotionIntensityModel
from utils.data_loader import get_dataloaders
from tqdm import tqdm
import os

def train_model():
    # Hyperparameters
    num_emotions = 7
    epochs = 5
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    print(f"Using device: {device}")
    
    # Create directories
    os.makedirs('checkpoints', exist_ok=True)
    
    # Load model
    model = EmotionIntensityModel(num_emotions=num_emotions).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-4)
    
    # Load data
    train_loader, val_loader = get_dataloaders(batch_size=8)
    print(f"Dataset loaded. Training batches: {len(train_loader)}, Validation batches: {len(val_loader)}")
    
    # Training loop
    best_val_acc = 0
    for epoch in range(epochs):
        # Training phase
        model.train()
        total_loss = 0
        correct = 0
        total = 0
        
        for batch_idx, (images, targets) in enumerate(tqdm(train_loader, desc=f"Epoch {epoch+1} Training")):
            images = images.to(device)
            targets = targets.to(device)
            
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            
            if batch_idx % 50 == 0:
                print(f'\nBatch [{batch_idx}/{len(train_loader)}], Loss: {loss.item():.4f}')
        
        train_loss = total_loss / len(train_loader)
        train_acc = 100. * correct / total
        
        # Validation phase
        model.eval()
        val_loss = 0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for images, targets in tqdm(val_loader, desc=f"Epoch {epoch+1} Validation"):
                images = images.to(device)
                targets = targets.to(device)
                outputs = model(images)
                loss = criterion(outputs, targets)
                
                val_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
        
        val_loss = val_loss / len(val_loader)
        val_acc = 100. * correct / total
        
        print(f"\nEpoch {epoch+1}")
        print(f"Training - Loss: {train_loss:.4f}, Accuracy: {train_acc:.2f}%")
        print(f"Validation - Loss: {val_loss:.4f}, Accuracy: {val_acc:.2f}%")
        
        # Save best model
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            print(f"\nSaving best model with validation accuracy: {val_acc:.2f}%")
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
            }, os.path.join('checkpoints', 'best_model.pth'))
    
    # Save final model
    final_path = os.path.join('checkpoints', 'final_model.pth')
    torch.save(model.state_dict(), final_path)
    print(f"\nTraining completed. Final model saved to {final_path}")

if __name__ == '__main__':
    mp.freeze_support()
    train_model()