import importlib
names = ["numpy","cv2","torch","torchvision","timm","flask","tqdm"]
for n in names:
    try:
        m = importlib.import_module(n)
        v = getattr(m, "__version__", None)
        print(n, v if v else "loaded")
    except Exception as e:
        print(n, "ERROR", e)
