import os
import pandas as pd
from sklearn.model_selection import train_test_split

def prepare_dataset(source_dir='dataset', dest_dir='data', val_split=0.2):
    os.makedirs(dest_dir, exist_ok=True)
    data = []

    classes = [d for d in os.listdir(source_dir) if os.path.isdir(os.path.join(source_dir, d))]
    for cls in classes:
        img_dir = os.path.join(source_dir, cls)
        for img in os.listdir(img_dir):
            if img.lower().endswith(('.jpg', '.jpeg', '.png')):
                data.append({'image': os.path.join(img_dir, img), 'label': cls})

    df = pd.DataFrame(data)
    train_df, val_df = train_test_split(df, test_size=val_split, stratify=df['label'], random_state=42)
    train_df.to_csv(os.path.join(dest_dir, 'train.csv'), index=False)
    val_df.to_csv(os.path.join(dest_dir, 'val.csv'), index=False)

    print(f"✅ Dataset prepared: {len(train_df)} train samples, {len(val_df)} validation samples.")
    print(f"Files saved to {dest_dir}/train.csv and {dest_dir}/val.csv")

if __name__ == "__main__":
    prepare_dataset()
